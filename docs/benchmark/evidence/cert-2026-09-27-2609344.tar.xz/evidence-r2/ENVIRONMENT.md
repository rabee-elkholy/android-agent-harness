# Certification environment (round 2: targeted re-run of T3, T8, T9, T10)

- App: Automattic/pocket-casts-android at 30ee0120ddfb168dae63a831fca309bbbc155c94; app skills moved to .claude/skills (df559f912, same developer commit as round 1)
- Baseline commit for every scenario: 22a75e51032d303d8a87de167e1886444f19d419 (df559f912 + harness 2609344 installed with the same answers as round 1)
- Harness: 26093446cb9d2b10fbbd179fb345ed89ea1ab4d9 (v1.1.2 + N1-N8/N10 fixes; CI 12/12 green), kit ~/.android-harness/kit-cert2 (frozen)
- Agent: Claude Code CLI 2.1.283 (Claude Code), headless -p, model claude-sonnet-5, effort medium, permission-mode acceptEdits, allowed: Bash Edit Write MultiEdit Read Grep Glob Agent Task TodoWrite; denied: git push, rm; budget cap 25 USD per step
- JDK: Picked up JAVA_TOOL_OPTIONS: -Djavax.net.ssl.trustStore=/etc/ssl/certs/java/cacerts -Djavax.net.ssl.trustStoreType=JKS -Dhttps.proxyHost=127.0.0.1 -Dhttps.proxyPort=38329 -Dhttp.nonProxyHosts=localhost|127.0.0.1|::1|127.*|0.*|::|169.254.*|api.anthropic.com|api-staging.anthropic.com|api-pr-preview.anthropic.com|mcp-proxy.anthropic.com|mcp-proxy-staging.anthropic.com|registry.npmjs.org|jsr.io|npm.jsr.io|pypi.org|files.pythonhosted.org|index.crates.io|proxy.golang.org|host.docker.internal|10.*|172.16.*|172.17.*|172.18.*|172.19.*|172.20.*|172.21.*|172.22.*|172.23.*|172.24.*|172.25.*|172.26.*|172.27.*|172.28.*|172.29.*|172.30.*|172.31.*|192.168.*|100.64.0.0/10|*.svc.cluster.local|*.svc.cluster.local -Djdk.http.auth.tunneling.disabledSchemes= -Djdk.http.auth.proxying.disabledSchemes=; Android SDK platform android-37.0, build-tools 37.0.0; no device
- Gradle: wrapper 9.7.1; Maven Central routed through Google's mirror and download retries raised (~/.gradle, environment only); Robolectric android-all jars already in ~/.m2 from round 1
- Doctor --install-check: 35 PASS, 0 WARN, 0 FAIL; unit-test baseline captured (0 pre-existing failures, 141 reports)
- Prompts: identical to round 1 (prompts/)
