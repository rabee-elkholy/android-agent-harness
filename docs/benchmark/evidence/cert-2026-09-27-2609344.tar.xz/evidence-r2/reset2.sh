#!/bin/bash
# Reset the app to the certification baseline: code at 22a75e510 and pristine harness state.
set -e
cd /home/user/cert/pocket-casts
git reset -q --hard 22a75e51032d303d8a87de167e1886444f19d419
git clean -qfd
rm -rf .agents/state .agents/cache
tar -xzf /home/user/cert/pristine-agents-state-r2.tgz
git log --oneline -1; git status --short | head -3; echo "state reset"
