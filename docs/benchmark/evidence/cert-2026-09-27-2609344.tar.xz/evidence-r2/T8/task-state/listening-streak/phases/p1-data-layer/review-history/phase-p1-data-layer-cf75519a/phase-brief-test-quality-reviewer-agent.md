# LEAN PHASE BRIEF: Test Quality Specialist (`test-quality-reviewer-agent`)
**Task ID**: listening-streak | **Phase ID**: p1-data-layer | **Run ID**: phase-p1-data-layer-cf75519a | **Package SHA**: `821b5147ee9a`

## 1. Approved Phase Objective & Delta Scope
- **Phase**: p1-data-layer
- **Description**: Streak tracking and storage
- **Focus**: Test coverage completeness, assertion depth, meaningful failure verification, and avoidance of dummy assertions.

## 2. Review Package Reference
`/home/user/cert/pocket-casts/.agents/state/tasks/listening-streak/phases/p1-data-layer/review/phase-review-package.md`

## 3. Structured Result Reporting Protocol (HARNESS_REVIEW_RESULT_V2)
End with exactly one machine-readable JSON code block matching schema_version 2:
```json
{
  "schema_version": 2,
  "task_id": "listening-streak",
  "run_id": "phase-p1-data-layer-cf75519a",
  "reviewer": "test-quality-reviewer-agent",
  "review_package_sha256": "821b5147ee9a090e2a11ca3388fd40cf02a7de947d32003f97b05e028ab2537a",
  "verdict": "PASS",
  "findings": []
}
```