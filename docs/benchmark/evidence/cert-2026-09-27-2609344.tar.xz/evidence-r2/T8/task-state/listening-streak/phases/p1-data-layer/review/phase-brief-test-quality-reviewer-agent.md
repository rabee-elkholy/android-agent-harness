# LEAN PHASE BRIEF: Test Quality Specialist (`test-quality-reviewer-agent`)
**Task ID**: listening-streak | **Phase ID**: p1-data-layer | **Run ID**: phase-p1-data-layer-08eb248c | **Package SHA**: `e04c2e8945ca`

## 1. Approved Phase Objective & Delta Scope
- **Phase**: p1-data-layer
- **Description**: Streak tracking and storage
- **Focus**: Test coverage completeness, assertion depth, meaningful failure verification, and avoidance of dummy assertions.

## 2. Review Package Reference
`/home/user/cert/pocket-casts/.agents/state/tasks/listening-streak/phases/p1-data-layer/review/phase-review-package.md`

## 3. Structured Result Reporting Protocol (HARNESS_REVIEW_RESULT_V2)
End with exactly one machine-readable JSON code block matching schema_version 2:
```json
{
  "schema_version": 2,
  "task_id": "listening-streak",
  "run_id": "phase-p1-data-layer-08eb248c",
  "reviewer": "test-quality-reviewer-agent",
  "review_package_sha256": "e04c2e8945cabf103132531c42ed5f7cf852aebef696e920b4ddad1167e8cc68",
  "verdict": "PASS",
  "findings": []
}
```