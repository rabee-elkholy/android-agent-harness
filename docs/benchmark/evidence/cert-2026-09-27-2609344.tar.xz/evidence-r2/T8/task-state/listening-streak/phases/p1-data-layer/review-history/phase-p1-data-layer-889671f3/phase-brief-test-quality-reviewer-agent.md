# LEAN PHASE BRIEF: Test Quality Specialist (`test-quality-reviewer-agent`)
**Task ID**: listening-streak | **Phase ID**: p1-data-layer | **Run ID**: phase-p1-data-layer-889671f3 | **Package SHA**: `15992d0b0839`

## 1. Approved Phase Objective & Delta Scope
- **Phase**: p1-data-layer
- **Description**: Streak tracking and storage
- **Focus**: Test coverage completeness, assertion depth, meaningful failure verification, and avoidance of dummy assertions.

## 2. Review Package Reference
`/home/user/cert/pocket-casts/.agents/state/tasks/listening-streak/phases/p1-data-layer/review/phase-review-package.md`

## 3. Structured Result Reporting Protocol (HARNESS_REVIEW_RESULT_V2)
End with exactly one machine-readable JSON code block matching schema_version 2:
```json
{
  "schema_version": 2,
  "task_id": "listening-streak",
  "run_id": "phase-p1-data-layer-889671f3",
  "reviewer": "test-quality-reviewer-agent",
  "review_package_sha256": "15992d0b0839066fced4dfa016c49fa8922a775f00b4348103dfad704c8dd29a",
  "verdict": "PASS",
  "findings": []
}
```