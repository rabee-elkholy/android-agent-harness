# LEAN PHASE BRIEF: Regression & Blast-Radius Impact (`regression-impact-reviewer-agent`)
**Task ID**: listening-streak | **Phase ID**: p2-profile-ui | **Run ID**: phase-p2-profile-ui-da87b9b8 | **Package SHA**: `0f0a3fbc20e6`

## 1. Approved Phase Objective & Delta Scope
- **Phase**: p2-profile-ui
- **Description**: Show current streak on Profile screen
- **Focus**: Breaking contract changes, modified public declarations, impact on upstream callers and downstream dependents.

## 2. Review Package Reference
`/home/user/cert/pocket-casts/.agents/state/tasks/listening-streak/phases/p2-profile-ui/review/phase-review-package.md`

## 3. Structured Result Reporting Protocol (HARNESS_REVIEW_RESULT_V2)
End with exactly one machine-readable JSON code block matching schema_version 2:
```json
{
  "schema_version": 2,
  "task_id": "listening-streak",
  "run_id": "phase-p2-profile-ui-da87b9b8",
  "reviewer": "regression-impact-reviewer-agent",
  "review_package_sha256": "0f0a3fbc20e60004b9c691aa11b58b52e81d5a6865f2a7b19e3d31beaa67d138",
  "verdict": "PASS",
  "findings": []
}
```