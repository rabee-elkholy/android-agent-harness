# T8 (round 2): Listening streak in two phases

| Item | Value |
|---|---|
| Result | **FAILED** (both phases were checkpointed, reviewed and finalized, and every gate passed including assemble, but `complete` refuses; not delivered) |
| Pass criterion | Two phases registered and shown in `PLAN_SUMMARY`; phase checkpoint and reviews per phase; delivered |
| App baseline | `22a75e510` |
| Harness | `2609344` (frozen) |
| Model / effort | `claude-sonnet-5` / medium |
| Steps | 10 agent turns; developer: design answers (one message), 9 plan approvals, 2 environment notes (a usage-limit interruption and a background command lost in headless mode) |
| Cost / wall time | $20.04 (cumulative session cost) / 48 min 6 s |

## What the agent did
1. It asked eight domain questions; the developer answered them in one message.
2. `draft --phases` (p1 data layer, 5 files; p2 Profile UI, 4 files). **N2 fix held:** `PLAN_SUMMARY` listed all 9 phase files, where round 1 listed one file. `Modules:` showed only `:modules:services:repositories`, taken from the task context, and `Surfaces:` included AUTH and BILLING from the `PlaybackManager` context. Developer approved (hash `d0454f2a8872`).
3. The `Settings.kt` edit was denied because the `preferences` module was not in scope. `revise` added the modules (hash `605bb3858162`); approval 2.
4. The turn was cut by the account usage limit. The developer resumed with "continue". The agent then started the p1 checkpoint in the background, which a headless turn does not keep alive, so the developer told it to run the checkpoint in the foreground.
5. p1 checkpoint passed (compile and tests). The phase review ran with `perf-anr-guardian-agent` and `test-quality-reviewer-agent` via package, dispatch, `complete --execution-id` and finalize, and **p1 was finalized**. `begin-next-phase` moved to p2.
6. A p2 edit to `ProfilePage.kt` needed a revision (approval 3). **After that revision the harness reset phase progress: `completed_phases=[]`, current phase p1.** The agent's p2 checkpoint was then refused ("active phase is 'p1'", the N1 check). Re-checkpointing p1 failed on the p2 file, so the agent revised again to move `ProfilePage.kt` into p2 (approval 4).
7. p1 was re-checkpointed, re-reviewed and finalized; then `begin-next-phase` and the p2 checkpoint (compile, tests; the resource-only `localization` module did not block, so N3 held), `prepare-verification`, preflight, unit-test gate, and the final reviewers (bug, perf/ANR, regression-impact, test-quality). **The bug reviewer found a real HIGH race condition** (non-atomic streak read-check-write). Fixing it needed a p1 file, so there was another revision (approval 5), and the phase progress reset again.
8. After the reset, `begin-next-phase` failed with `next phase baseline differs from the current delivery snapshot`, because the stale p2 baseline from the first pass remained. `reconcile-delivery` did not help, and the agent revised again to resync (approval 6).
9. Both phases were redone and finalized; the p2 phase review passed. Final verification: preflight, tests, **assemble `:app:assembleDebug` PASS**, and four final reviewers PASS; the race fix (`@Singleton` + `@Synchronized`) was confirmed. The router returned `COMPLETE_TASK`. `workflow.py complete` failed with `PLAN_APPROVAL_REQUIRED: mandatory skill selection drifted from the approved plan: compose-inspector`. The agent's extra `android-ui-expert-agent` pass was rejected as outside the roster. It stopped and asked the developer.

## Gates, reviewers, enforcement
- Phases: registered and shown. Per-phase checkpoint and review worked for both phases (p1 three times, p2 twice).
- Gates: compile, unit tests (per module; resource-only localization not blocking), preflight, assemble: all PASS.
- Reviewers: phase reviews (perf/ANR, test-quality; bug, regression-impact) and final reviews (bug, perf/ANR, regression-impact, test-quality). One real HIGH finding, fixed and verified.
- Plan approvals: 9 in total, 6 of them caused by harness state and not by scope changes.
- Auditor check: `workflow.py complete` was re-run once after the round to capture the exact refusal (`complete-replay.txt`); it failed the same way.

## Final state
Not delivered, so T9 cannot start. Task `VERIFYING`, and the router says `COMPLETE_TASK`, which fails. Diff: 7 tracked files, +46 -2, plus the new `ListeningStreakManager.kt` and its test. Files: `final.diff`, `final-status.txt`, `final-router.txt`, `task-state/`.

## Why FAILED
The task is not delivered. The round-1 blockers are gone: the N2 files are in scope, N3 no longer fails resource-only modules, N1 enforces the active phase, and both phases complete. The run now ends on a new verifier dead end, and on the way it hit two new phase-state defects.

## New harness issues
- **N12: plan skills vs. verification skills.** At verification the policy selects `compose-inspector` for the COMPOSE_UI surface of the actual change. The plan's skills (taken at draft from the plan surfaces, which lacked COMPOSE_UI) do not include it, so `complete` refuses with `PLAN_APPROVAL_REQUIRED`. Meanwhile the router says `COMPLETE_TASK` and names no revise path.
- **N13 (the N4 fix is incomplete):** a revision still drops finalized phases once a later phase has edits. Phase-review freshness re-derives the completed phase's delta from the live tree, sees the later phase's files, and reports `phase delta SHA-256 changed` (reproduced from the saved `review-history` run).
- **N14:** after that reset, the stale next-phase `baseline.json` makes `begin-next-phase` fail with `next phase baseline differs from the current delivery snapshot`.
- **N2 residual:** with `--phases` the plan's files come from the phases, but `Modules:` and `Surfaces:` still come from the task context (one module; AUTH and BILLING from `PlaybackManager`).
