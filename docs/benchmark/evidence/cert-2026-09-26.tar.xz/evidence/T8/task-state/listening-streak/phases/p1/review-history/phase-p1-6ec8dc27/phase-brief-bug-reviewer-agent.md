# LEAN PHASE BRIEF: Bug & Logic Reviewer (`bug-reviewer-agent`)
**Task ID**: listening-streak | **Phase ID**: p1 | **Run ID**: phase-p1-6ec8dc27 | **Package SHA**: `2b9dbbd59a71`

## 1. Approved Phase Objective & Delta Scope
- **Phase**: p1
- **Description**: Data layer: streak tracking and storage
- **Focus**: Logic defects, null-safety, unhandled exceptions, race conditions, and incorrect state mutations.

## 2. Review Package Reference
`/home/user/cert/pocket-casts/.agents/state/tasks/listening-streak/phases/p1/review/phase-review-package.md`

## 3. Structured Result Reporting Protocol (HARNESS_REVIEW_RESULT_V2)
End with exactly one machine-readable JSON code block matching schema_version 2:
```json
{
  "schema_version": 2,
  "task_id": "listening-streak",
  "run_id": "phase-p1-6ec8dc27",
  "reviewer": "bug-reviewer-agent",
  "review_package_sha256": "2b9dbbd59a71a4910e62aadc4bab964ebd81e7b151e2194a26772ec978709078",
  "verdict": "PASS",
  "findings": []
}
```