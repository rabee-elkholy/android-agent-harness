# LEAN PHASE BRIEF: Bug & Logic Reviewer (`bug-reviewer-agent`)
**Task ID**: listening-streak | **Phase ID**: p1 | **Run ID**: phase-p1-aa92a308 | **Package SHA**: `9816bf24c7ff`

## 1. Approved Phase Objective & Delta Scope
- **Phase**: p1
- **Description**: Data layer: streak tracking and storage
- **Focus**: Logic defects, null-safety, unhandled exceptions, race conditions, and incorrect state mutations.

## 2. Review Package Reference
`/home/user/cert/pocket-casts/.agents/state/tasks/listening-streak/phases/p1/review/phase-review-package.md`

## 3. Structured Result Reporting Protocol (HARNESS_REVIEW_RESULT_V2)
End with exactly one machine-readable JSON code block matching schema_version 2:
```json
{
  "schema_version": 2,
  "task_id": "listening-streak",
  "run_id": "phase-p1-aa92a308",
  "reviewer": "bug-reviewer-agent",
  "review_package_sha256": "9816bf24c7ffca1c6ab0713ad0ba68a37d361692ddf81b5fe396514f80a53d0b",
  "verdict": "PASS",
  "findings": []
}
```