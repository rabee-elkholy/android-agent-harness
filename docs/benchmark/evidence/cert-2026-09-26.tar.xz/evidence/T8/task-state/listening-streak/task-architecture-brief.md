# Task Architecture Brief

- **Architecture Mode**: `PRESERVE`
- **Target Scope**: `modules/features/profile/src/main/java/au/com/shiftyjelly/pocketcasts/profile/ProfileViewModel.kt`
- **Active Local Family**: `project local`
- **Rule**: Preserve this local family. Do not modernize or convert UI toolkit, ViewModel base, or state stream.
- **Forbidden**: Converting XML to Compose, replacing BaseViewModel with MviViewModel, or LiveData to StateFlow unless explicitly approved in a MIGRATE task.
