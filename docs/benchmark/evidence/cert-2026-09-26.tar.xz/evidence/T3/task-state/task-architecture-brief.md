# Task Architecture Brief

- **Architecture Mode**: `PRESERVE`
- **Target Scope**: `modules/services/model/src/main/java/au/com/shiftyjelly/pocketcasts/models/db/AppDatabase.kt`
- **Active Local Family**: `project local`
- **Rule**: Preserve this local family. Do not modernize or convert UI toolkit, ViewModel base, or state stream.
- **Forbidden**: Converting XML to Compose, replacing BaseViewModel with MviViewModel, or LiveData to StateFlow unless explicitly approved in a MIGRATE task.
