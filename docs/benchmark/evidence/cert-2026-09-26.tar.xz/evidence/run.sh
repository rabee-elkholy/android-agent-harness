#!/bin/bash
# usage: run.sh <scenario> <message-file> [--resume]
# Runs one agent turn of a scenario in the app, frozen model/effort, saving the raw stream.
set -u
ID=$1; MSG=$2; MODE=${3:-}
APP=/home/user/cert/pocket-casts; EV=/home/user/cert/evidence/$ID
mkdir -p "$EV"; cd "$APP"
export ANDROID_HOME=/opt/android-sdk
N=$(ls "$EV"/step*.summary.txt 2>/dev/null | wc -l); N=$((N+1))
if [ "$MODE" = "--resume" ]; then SESSION=$(cat "$EV/session"); SESS_ARGS=(--resume "$SESSION")
else SESSION=$(python3 -c 'import uuid;print(uuid.uuid4())'); echo "$SESSION" > "$EV/session"; SESS_ARGS=(--session-id "$SESSION"); fi
cp "$MSG" "$EV/step$N.prompt.txt"
AUDIT=$APP/.agents/state/audit_log.jsonl; A0=$( [ -f "$AUDIT" ] && wc -l < "$AUDIT" || echo 0 )
START=$(date +%s)
claude -p "$(cat "$MSG")" "${SESS_ARGS[@]}" --model claude-sonnet-5 --effort medium \
  --output-format stream-json --verbose --permission-mode acceptEdits \
  --allowedTools Bash Edit Write MultiEdit Read Grep Glob Agent Task TodoWrite \
  --disallowedTools "Bash(git push:*)" "Bash(rm:*)" \
  --max-budget-usd 25 > "$EV/step$N.jsonl" 2> "$EV/step$N.stderr"
RC=$?; END=$(date +%s)
[ -f "$AUDIT" ] && tail -n +$((A0+1)) "$AUDIT" > "$EV/step$N.audit.jsonl"
python3 - "$EV/step$N.jsonl" "$RC" "$((END-START))" <<'PY' | tee "$EV/step$N.summary.txt"
import json,sys
path,rc,secs=sys.argv[1],sys.argv[2],sys.argv[3]
res=None; models=set()
for line in open(path,encoding="utf-8",errors="replace"):
    try: e=json.loads(line)
    except ValueError: continue
    if e.get("type")=="assistant": models.add((e.get("message") or {}).get("model"))
    if e.get("type")=="result": res=e
print(f"exit={rc} wall_s={secs} models={sorted(m for m in models if m)}")
if res:
    print(f"cost_usd={res.get('total_cost_usd')} turns={res.get('num_turns')} is_error={res.get('is_error')} subtype={res.get('subtype')}")
    print("RESULT:", (res.get('result') or '')[-3000:])
PY
