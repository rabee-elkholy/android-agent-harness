#!/bin/bash
# Reset the app to the certification baseline: code at ea005dd and pristine harness state.
set -e
cd /home/user/cert/pocket-casts
git reset -q --hard ea005ddde6fd5bec042d120818b7e969a1e475e6
git clean -qfd
rm -rf .agents/state .agents/cache
tar -xzf /home/user/cert/pristine-agents-state.tgz
git log --oneline -1; git status --short | head -3; echo "state reset"
