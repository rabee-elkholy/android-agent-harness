# Task Architecture Brief

- **Architecture Mode**: `PRESERVE`
- **Target Scope**: `app/src/main/AndroidManifest.xml`
- **Active Local Family**: `compose-activity-viewmodel-stateflow-hilt`
- **Rule**: Preserve this local family. Do not modernize or convert UI toolkit, ViewModel base, or state stream.
- **Forbidden**: Converting XML to Compose, replacing BaseViewModel with MviViewModel, or LiveData to StateFlow unless explicitly approved in a MIGRATE task.

## Reference Exemplars
- `app/src/main/java/au/com/shiftyjelly/pocketcasts/ui/MainActivity.kt`
- `app/src/main/java/au/com/shiftyjelly/pocketcasts/ui/MainActivityViewModel.kt`
- `modules/features/endofyear/src/main/java/au/com/shiftyjelly/pocketcasts/endofyear/EndOfYearViewModel.kt`
- `modules/features/endofyear/src/main/java/au/com/shiftyjelly/pocketcasts/endofyear/StoriesActivity.kt`
- `modules/features/player/src/main/java/au/com/shiftyjelly/pocketcasts/player/view/bookmark/BookmarkActivity.kt`
