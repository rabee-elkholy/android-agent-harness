import json, sys
from pathlib import Path
ev = Path("/home/user/cert/evidence") / sys.argv[1]
steps = sys.argv[2:] or sorted({p.name.split(".")[0] for p in ev.glob("step*.summary.txt")}, key=lambda s: int(s[4:]))
for step in steps:
    print(f"===== {step}")
    for line in open(ev / f"{step}.jsonl", encoding="utf-8", errors="replace"):
        try: e = json.loads(line)
        except ValueError: continue
        if e.get("type") == "assistant":
            for b in e["message"].get("content") or []:
                if b.get("type") == "tool_use":
                    i = b["input"]
                    what = i.get("command") or i.get("file_path") or i.get("subagent_type") or i.get("description") or ""
                    print("  TOOL", b["name"], str(what).replace("\n", " ")[:170])
        if e.get("type") == "user":
            for b in (e.get("message") or {}).get("content") or []:
                if isinstance(b, dict) and b.get("type") == "tool_result" and b.get("is_error"):
                    c = b.get("content"); c = c if isinstance(c, str) else json.dumps(c)
                    print("    ! ERR", c.replace("\n", " ")[:200])
    audit = ev / f"{step}.audit.jsonl"
    if audit.is_file():
        for line in open(audit):
            r = json.loads(line)
            if r.get("decision") == "deny":
                print("  DENY", r.get("reason_code"), str(r.get("reason") or "")[:200])
    print(open(ev / f"{step}.summary.txt").read().split("RESULT:")[0].strip())
