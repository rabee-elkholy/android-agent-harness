# Certification environment

- App: Automattic/pocket-casts-android at 30ee0120ddfb168dae63a831fca309bbbc155c94
- Baseline commit for every scenario: ea005ddde6fd5bec042d120818b7e969a1e475e6 (app skills moved to .claude/skills; harness v1.1.2 installed with Claude Code host, tracker none, device verification disabled)
- Harness: v1.1.2, e36ea2031f498bd5e8fce43005538888d1b9b5f3, kit ~/.android-harness/kit-cert (frozen)
- Agent: Claude Code CLI 2.1.283 (Claude Code), headless -p, model claude-sonnet-5, effort medium, permission-mode acceptEdits, allowed: Bash Edit Write MultiEdit Read Grep Glob Agent Task TodoWrite; denied: git push, rm; budget cap 25 USD per step
- JDK: openjdk version "21.0.10" 2026-01-20; Android SDK platform android-37.0, build-tools 37.0.0; no device
- Gradle: wrapper 9.7.1; Maven Central routed through Google's mirror and download retries raised (~/.gradle, environment only)
- Doctor --install-check: 35 PASS, 0 WARN, 0 FAIL; unit-test baseline captured (0 pre-existing failures)
- Host: cloud container, 4 CPU, 15 GB RAM
